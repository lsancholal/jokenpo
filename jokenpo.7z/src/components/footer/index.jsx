import styles from './footer.module.css'

function Footer() {
    return (
        <footer className={styles.footer}>
           <div>

           

           </div>
            

        </footer>
    )
}

export default Footer
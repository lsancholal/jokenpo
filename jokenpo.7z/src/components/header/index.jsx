import styles from './header.module.css'

function Header() {
    return (
        <header className={styles.header}>
            <div>

            <p>Pedra Papel e Tesoura</p>

            </div>

        </header>
    )
}

export default Header